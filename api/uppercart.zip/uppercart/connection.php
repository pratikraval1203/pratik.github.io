
<?php

$hostname='localhost';
$username='root';
$userpass='';
$dbname='userdata';

$con=mysqli_connect($hostname,$username,$userpass,$dbname);

/*if(!$con){
	echo"connection failed";
}
 else
 echo "connection succes";
?>*/